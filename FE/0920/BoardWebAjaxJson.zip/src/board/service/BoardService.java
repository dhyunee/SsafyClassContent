package board.service;

import board.dto.UserDto;

public interface BoardService {
	public void BoardDto write(string title,string content)
	
}
